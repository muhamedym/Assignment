# Developer notes (not needed to use the app)

- `extract_vocab.py`: reads the IELTS .docx and writes `vocab.json` using only the answer columns
  (fails if an "earlier spelling" or a UK spelling would become an answer).
  `python -I dev/extract_vocab.py "IELTS_Essential_Spelling_and_Vocabulary.docx" dev/vocab.json`
- `build_listening_hf.py`: cleans `listening_hf_source.txt` (the "378 High Frequency Words in IELTS Listening"
  list) into US-spelled, de-duplicated entries and appends them to `vocab.json`. Run it after `extract_vocab.py`.
- `wordinfo/*.txt` + `add_word_info.py`: part of speech, meaning, example sentence and word family for every
  word (checked: complete, and every sentence contains the exact word), plus text-to-speech fixes (resume → résumé).
- `reading_words.txt` + `build_reading.py`: the 98 Academic Reading words by topic, with word info (run after
  `add_word_info.py`).
- `make_icons.py`, `build_site.py`, `store_screenshots.mjs`: build `play-store/` (installable web version for
  the Android app, icons, Play Store screenshots). `tests/site.test.mjs` checks the hosted version works offline.
- `add_pronunciation.py`: American IPA, syllables and letter-to-sound breakdown (silent/double letters) for
  every word, from the CMU Pronouncing Dictionary (`cmudict-subset.txt`, licence in `cmudict-LICENSE.txt`).
  Run after `build_reading.py`. `cmudict-full.txt.gz` (126,037 words) gives words people add a pronunciation in the app.
- `build_wordnet.py`: makes `wordnet-compact.txt.gz` (40,984 words: parts of speech, meaning, up to two
  example sentences that use the word, similar words, word family) from WordNet 3.1, the built-in dictionary
  for words people add. The WordNet files come from the npm package `wordnet-db`
  (`npm pack wordnet-db && tar xzf wordnet-db-*.tgz`, then `python -I dev/build_wordnet.py package/dict`).
  Licence: `wordnet-LICENSE.txt`.
- `sounds_content.py` + `build_sounds.py`: the Sounds page. `sounds_content.py` has the 41 sounds (key word, examples,
  steps, tips, word pairs). `build_sounds.py` records them with the Kokoro-82M voice model (Apache-2.0; from the npm
  packages `kokoro-q8-shards` and `kokoro-js`) into `sounds-audio.json`: words are said in "Listen. <word>." and cut
  out with the model's own timing; single sounds are cut from a syllable and lengthened (PSOLA for voiced sounds).
  With `--verify`, every word is checked with Whisper (npm `sts-whisper-base`, run with transformers.js) against the
  words it is paired with on the page and other real words that differ by one sound, and re-recorded if needed.
  See the top of `build_sounds.py`.
- `build.py`: injects `vocab.json`, the pronunciation dictionary, the WordNet dictionary and the Sounds page
  (`sounds_content.py` + `sounds-audio.json`) into
  `IELTS-Spelling-Dictation/IELTS-Spelling-Dictation.html`.
  `python -I dev/build.py`
- `tests/e2e.test.mjs`: 26 end-to-end tests in headless Chromium (Playwright) against the real page. The online
  dictionaries (dictionaryapi.dev, Wiktionary, Wikipedia, datamuse) are simulated with responses in their documented formats.
  `tests/mock-speech.js` simulates the Web Speech API (late-loading voices, queueing, cancel) so the
  timing and overlap rules can be checked; the "no voices" test uses real Chromium with no speech engine.
  `node dev/tests/e2e.test.mjs` (or `ONLY="Sounds" node dev/tests/e2e.test.mjs` for some of them)
